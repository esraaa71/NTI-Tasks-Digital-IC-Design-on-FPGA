module tb;

reg [31:0] data_in;
wire [7:0] byte_high;
wire [7:0] byte_low;
wire parity_bit;

data_router U1(
data_in,
byte_high,
byte_low,
parity_bit
);

reg clk;
reg [2:0] read_addr;
reg [2:0] write_addr;
reg [15:0] write_data;
reg we;
wire [15:0] read_data;
wire [7:0] read_data_top_byte;

reg_file U2(
clk,
read_addr,
write_addr,
write_data,
we,
read_data,
read_data_top_byte
);

reg grid_clk;
reg rst;
reg oe;
reg endian_swap;
reg [1:0] row_addr;
reg col_addr;
wire [31:0] processing_word;
wire [7:0] bus_data;

grid_mem_router U3(
grid_clk,
rst,
oe,
endian_swap,
row_addr,
col_addr,
processing_word,
bus_data
);

initial begin

data_in = 32'hA1B2C3D4;

clk = 0;
write_addr = 0;
write_data = 16'h1234;
we = 0;
read_addr = 0;

#5;
we = 1;
#5;
clk = 1;
#5;
clk = 0;
we = 0;

#5;
read_addr = 0;

grid_clk = 0;
rst = 1;
oe = 0;
endian_swap = 0;
row_addr = 0;
col_addr = 0;

#10;
rst = 0;

U3.fabric_mem[0][0] = 8'h11;
U3.fabric_mem[1][0] = 8'h22;
U3.fabric_mem[2][0] = 8'h33;
U3.fabric_mem[3][0] = 8'h44;

#5;
grid_clk = 1;
#5;
grid_clk = 0;

$display("Data Router: high=%h low=%h parity=%b", byte_high, byte_low, parity_bit);
$display("Register File: read=%h top=%h", read_data, read_data_top_byte);
$display("Grid Normal: %h", processing_word);

endian_swap = 1;

#5;
grid_clk = 1;
#5;
grid_clk = 0;

$display("Grid Swapped: %h", processing_word);

oe = 1;
row_addr = 2;
col_addr = 0;

#5;
$display("Bus Data: %h", bus_data);

$finish;

end

endmodule
