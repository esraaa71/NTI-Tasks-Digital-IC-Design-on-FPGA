module memory_ctrl(
input wire [7:0] data_in,
output reg [15:0] addr_bus,
inout wire data_bus,
input wire clk
);

wire [31:0] full_word;
reg [7:0] grid_mem [0:3][0:1];
reg [4:0] start_idx;

assign data_bus = 1'bz;

always @(*) begin
grid_mem[0][0] = 8'hFF;
grid_mem[1][0] = 8'h00;
addr_bus[3:0] = full_word[start_idx +: 4];
end

endmodule
