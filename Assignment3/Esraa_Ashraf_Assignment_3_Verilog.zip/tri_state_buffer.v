module tri_state_buffer(
input wire [7:0] tx_data,
input wire tx_en,
inout wire [7:0] shared_bus
);

assign shared_bus = tx_en ? tx_data : 8'bz;

endmodule
