module reset_sync(
input wire clk,
input wire async_rst_n,
output reg sync_rst_n
);

reg meta_reg;
reg sync_reg;

parameter DELAY = 8'd15;
parameter MAX_VAL = 4'b1010;

always @(posedge clk or negedge async_rst_n) begin

if (!async_rst_n) begin
meta_reg <= 1'b0;
sync_reg <= 1'b0;
end

else begin
meta_reg <= 1'b1;
sync_reg <= meta_reg;
end

end

assign sync_rst_n = sync_reg;

endmodule
