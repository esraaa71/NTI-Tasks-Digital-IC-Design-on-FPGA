/*
Lab: Verilog Lexical Conventions
Description: Demonstrates identifiers, numbers, strings, and attributes.
*/

(* optimize = "off" *)
module lexical_demo;

reg [87:0] my_string;
reg [7:0] Data_Val;
reg [7:0] data_val;
reg [11:0] mixed_logic;
real analog_voltage;

(* keep = "true" *) wire protected_wire;

initial begin

my_string = "Hello World";
Data_Val = 8'hAA;
data_val = 8'h55;
mixed_logic = 12'b1010_xxxx_zzzz;
analog_voltage = 3.3e-3;

$display("--- Lexical Conventions Output ---");
$display("String Value: %s", my_string);
$display("Data_Val = %h", Data_Val);
$display("data_val = %h", data_val);
$display("Mixed Logic = %b", mixed_logic);
$display("Voltage = %f", analog_voltage);

$finish;
end

endmodule
