module tb_alu_8bit;

reg [7:0] A;
reg [7:0] B;
reg Cin;
reg [4:0] Control;
wire [15:0] Out;

alu_8bit U1(
A,
B,
Cin,
Control,
Out
);

task test;
input [4:0] op;
begin
Control = op;
#10;
$display("A=%h B=%h Cin=%b Control=%b Out=%h",
A,B,Cin,Control,Out);
end
endtask

initial begin

A = 8'h15;
B = 8'h03;
Cin = 0;

test(5'b00000);
test(5'b00001);
test(5'b00010);
test(5'b00011);
test(5'b00100);
test(5'b00101);
test(5'b00110);
test(5'b00111);
test(5'b01000);
test(5'b01001);
test(5'b01010);
test(5'b01011);
test(5'b01100);
test(5'b01101);
test(5'b01110);
test(5'b01111);
test(5'b10000);
test(5'b10001);
test(5'b10010);

Cin = 1;
test(5'b10011);

test(5'b10100);
test(5'b10101);
test(5'b10110);

A = 8'hFF;
B = 8'h01;
Cin = 0;

test(5'b00000);
test(5'b00100);
test(5'b00101);
test(5'b01111);

A = 8'h80;
B = 8'h02;

test(5'b01111);

$finish;

end

endmodule
