module alu_8bit(
input wire [7:0] A,
input wire [7:0] B,
input wire Cin,
input wire [4:0] Control,
output reg [15:0] Out
);

reg [15:0] temp;

always @(*) begin

Out = 16'b0;
temp = 16'b0;

case(Control)

5'b00000: Out = {8'b0,A} + {8'b0,B};

5'b00001: Out = {8'b0,A} + {8'b0,B} + 16'd1;

5'b00010: Out = {8'b0,A} + {8'b0,~B} + 16'd1;

5'b00011: Out = {8'b0,A} + {8'b0,~B};

5'b00100: Out = {8'b0,A} + 16'd1;

5'b00101: Out = {8'b0,A} - 16'd1;

5'b00110: Out = (A * B) + 16'd1;

5'b00111: Out = {8'b0,(A & B)};

5'b01000: Out = {8'b0,(A | B)};

5'b01001: Out = {8'b0,(A ^ B)};

5'b01010: Out = {8'b0,~A};

5'b01011: Out = {8'b0,~(A & B)};

5'b01100: Out = ({8'b0,A}) << B;

5'b01101: Out = {8'b0,A} >> B;

5'b01110: Out = {8'b0,A} << B;

5'b01111: Out = {{8{A[7]}},A} >>> B;

5'b10000: begin
temp = ({A,A} >> B[2:0]);
Out = {8'b0,temp[7:0]};
end

5'b10001: begin
temp = ({A,A} << B[2:0]) >> 8;
Out = {8'b0,temp[7:0]};
end

5'b10010: begin
if (A >= B)
Out = {8'b0,A};
else
Out = {8'b0,B};
end

5'b10011: begin
if (Cin)
Out = {8'b0,B};
else
Out = {8'b0,A};
end

5'b10100: Out = {~B,~A};

5'b10101: Out = {10'b0,(A >= B),(A > B),(A == B),(A <= B),(A < B),(A != B)};

5'b10110: Out = {14'b0,~^B,^A};

default: Out = 16'b0;

endcase

end

endmodule
