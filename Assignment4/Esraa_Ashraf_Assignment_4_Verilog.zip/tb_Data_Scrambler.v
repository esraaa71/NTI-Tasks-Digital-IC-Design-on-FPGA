module tb_Data_Scrambler;

reg signed [7:0] data_in;
reg [1:0] scramble_key;
reg [1:0] op_mode;
reg sleep_mode;

wire [7:0] data_out;
wire parity_err;
wire is_zero;

Data_Scrambler U1(
data_in,
scramble_key,
op_mode,
sleep_mode,
data_out,
parity_err,
is_zero
);

task test;
input [1:0] mode;
begin
op_mode = mode;
#10;
$display("data_in=%h key=%b mode=%b sleep=%b data_out=%h parity=%b zero=%b",
data_in,scramble_key,op_mode,sleep_mode,data_out,parity_err,is_zero);
end
endtask

initial begin

data_in = 8'h35;
scramble_key = 2'b10;
sleep_mode = 0;

test(2'b00);
test(2'b01);
test(2'b10);
test(2'b11);

data_in = -8'sd8;
test(2'b10);

data_in = 8'h00;
test(2'b00);

data_in = 8'hFF;
test(2'b00);

sleep_mode = 1;
test(2'b00);

data_in = -8'sd128;
sleep_mode = 0;
test(2'b10);

$finish;

end

endmodule
