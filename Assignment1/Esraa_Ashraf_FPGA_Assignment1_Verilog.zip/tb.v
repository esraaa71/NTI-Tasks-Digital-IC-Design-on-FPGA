module tb;

reg A;
reg B;
reg Cin;

wire Sum_gate;
wire Cout_gate;

wire Sum_struct;
wire Cout_struct;

wire Sum_beh;
wire Cout_beh;


full_adder_gate G1(
A,
B,
Cin,
Sum_gate,
Cout_gate
);


full_adder_structural S1(
A,
B,
Cin,
Sum_struct,
Cout_struct
);


full_adder_behavioral B1(
A,
B,
Cin,
Sum_beh,
Cout_beh
);


initial begin

A=0; B=0; Cin=0;
#10;

A=0; B=0; Cin=1;
#10;

A=0; B=1; Cin=0;
#10;

A=0; B=1; Cin=1;
#10;

A=1; B=0; Cin=0;
#10;

A=1; B=0; Cin=1;
#10;

A=1; B=1; Cin=0;
#10;

A=1; B=1; Cin=1;
#10;

$finish;

end


initial begin

$monitor("A=%b B=%b Cin=%b | Gate=%b%b Structural=%b%b Behavioral=%b%b",
A,B,Cin,Cout_gate,Sum_gate,Cout_struct,Sum_struct,Cout_beh,Sum_beh);

end

endmodule
