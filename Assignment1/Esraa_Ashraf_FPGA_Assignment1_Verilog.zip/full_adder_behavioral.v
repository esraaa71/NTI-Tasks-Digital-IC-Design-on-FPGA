module full_adder_behavioral(
input A,
input B,
input Cin,
output Sum,
output Cout
);

assign {Cout,Sum}=A+B+Cin;

endmodule
