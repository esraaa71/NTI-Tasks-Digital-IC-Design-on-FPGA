module half_adder(
input A,
input B,
output Sum,
output Carry
);

xor(Sum,A,B);
and(Carry,A,B);

endmodule


module full_adder_structural(
input A,
input B,
input Cin,
output Sum,
output Cout
);

wire s1;
wire c1;
wire c2;

half_adder HA1(
A,
B,
s1,
c1
);

half_adder HA2(
s1,
Cin,
Sum,
c2
);

or(Cout,c1,c2);

endmodule
